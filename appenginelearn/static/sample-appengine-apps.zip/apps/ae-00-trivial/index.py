print 'Content-Type: text/plain'
print ''
print 'Hello there Chuck'
