Fri Nov 21 15:00:45 EST 2008

HelperScripts for the AppEngine

These scripts assume that you have installed AppEngine on your Mac
or PC.   On the Mac you have also started the full-screen environment
once to extablish the sybmolic links.

PC Instructions

Copy the file appengine.bat into the apps directory - where each of your
applications is a sub folder.  Start the server as follows:

appengine ae-07-grades

Where "ae-07-grades" is the folder of the application you wish to start.  
It is also OK to say


appengine.bat ae-07-grades

Mac Instructions

Copy the file appengine.sh into the apps directory - where each of your
applications is a sub folder.  Start the server as follows:

sh appengine.sh ae-07-grades

That is it.

/Chuck
Where "ae-07-grades" is the folder of the application you wish to start.  



