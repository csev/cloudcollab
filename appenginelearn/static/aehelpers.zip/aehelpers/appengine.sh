
if [ -z "$1" ];
then
   echo " "
   echo "Please specify the folder name as the first parameter"
   echo " "
   exit
fi

if [ -d "$1" ];
then
  echo "Checking " $1
else
   echo " "
   echo "Error: Folder $1 does not exist"
   echo " "
   exit
fi

WHERE=""
if [ -f "$1/app.yaml" ];
then
   WHERE="$1"
fi

if [ -f "$1/$1/app.yaml" ];
then
   WHERE="$1/$1"
fi

if [ -z "$WHERE" ];
then
    echo " "
    echo "Error: app.yaml not found in the folder - " $1
    echo " "
    exit
fi

CMD="/usr/local/bin/dev_appserver.py"
if [ -f $CMD ];
then
    $CMD $WHERE
else
    echo " "
    echo "Error, could not find AppEngine startup"
    echo " "
    echo $CMD
    echo " "
    echo "AppEngine Install either failed or is incomplete."
    echo " "
fi

